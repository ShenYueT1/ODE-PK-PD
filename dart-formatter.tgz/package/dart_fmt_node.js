/* @ts-self-types="./dart_fmt.d.ts" */
import { readFileSync } from "node:fs";
import { formatWrapper, initSync } from "./dart_fmt.mjs";

const wasmUrl = new URL("dart_fmt.wasm", import.meta.url);
const wasmBytes = readFileSync(wasmUrl);
const wasmModule = new WebAssembly.Module(wasmBytes);

const app = initSync(wasmModule);

export function format(source, filename, options) {
	return formatWrapper(app, source, filename, options);
}
